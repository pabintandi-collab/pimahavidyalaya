import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import NoticeBoard from './components/NoticeBoard';
import AboutSection from './components/AboutSection';
import AcademicsSection from './components/AcademicsSection';
import StaffSection from './components/StaffSection';
import ActivitiesSection from './components/ActivitiesSection';
import AdmissionsSection from './components/AdmissionsSection';
import ContactSection from './components/ContactSection';
import AdminPanel from './components/AdminPanel';
import Footer from './components/Footer';
import { defaultCollegeData } from './data/defaultData';
import { CollegeData, StudentMessage, PageType } from './types';
import PortalBento from './components/PortalBento';
import { ArrowUp, Sparkles, CheckCircle2 } from 'lucide-react';

const CONFIG_STORAGE_KEY = 'pidc_portal_config_v1';
const MESSAGES_STORAGE_KEY = 'pidc_student_messages_v1';

const defaultStudentMessages: StudentMessage[] = [
  {
    id: "msg-101",
    name: "Abhishek Patnaik",
    email: "abhishek.p99@gmail.com",
    message: "I submitted my SAMS Odisha CAF registration on June 8. When is SAMS first selection candidate lists published for +2 Science honours streams? What is previous cutoffs?",
    timestamp: "June 09, 2026, 10:24 AM"
  },
  {
    id: "msg-102",
    name: "Priyanka Sahu",
    email: "priyanka.sahu99@yahoo.co.in",
    message: "Does your college offer Botany Honours under SAMS +3 degree stream? What is the general seat availability count and cutoff percentage for SAMS general category?",
    timestamp: "June 11, 2026, 03:45 PM"
  }
];

export default function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [collegeData, setCollegeData] = useState<CollegeData>(defaultCollegeData);
  const [messages, setMessages] = useState<StudentMessage[]>(defaultStudentMessages);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [saveBanner, setSaveBanner] = useState(false);

  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const storedConfig = localStorage.getItem(CONFIG_STORAGE_KEY);
      if (storedConfig) {
        const parsed = JSON.parse(storedConfig);
        let updated = false;
        if (parsed.hero) {
          if (parsed.hero.eyebrow === "Welcome to P.I. Mahavidyalaya" || !parsed.hero.eyebrow) {
            parsed.hero.eyebrow = defaultCollegeData.hero.eyebrow;
            updated = true;
          }
          if (!parsed.hero.slideshow || !Array.isArray(parsed.hero.slideshow) || parsed.hero.slideshow.length === 0) {
            parsed.hero.slideshow = defaultCollegeData.hero.slideshow;
            updated = true;
          }
        }
        if (parsed.about) {
          if (!parsed.about.principalAuthor || parsed.about.principalAuthor === "Dr. A. K. Sharma") {
            parsed.about.principalAuthor = defaultCollegeData.about.principalAuthor;
            parsed.about.principalRole = defaultCollegeData.about.principalRole;
            parsed.about.principalImagePlaceholder = defaultCollegeData.about.principalImagePlaceholder;
            updated = true;
          }
          if (parsed.about.principalImage === undefined || parsed.about.principalImage === "/principal.svg") {
            parsed.about.principalImage = defaultCollegeData.about.principalImage;
            updated = true;
          }
        }
        if (parsed.staff && Array.isArray(parsed.staff)) {
          const hasOldStaff = parsed.staff.some((s: any) => 
            s.name === "Prof. Manasa Ranjan Panda" || 
            s.name === "Mrs. Priyadarshini Mohanty" || 
            s.name === "Dr. A. K. Sharma" || 
            s.name === "Mr. Biswajit Das" || 
            s.name === "Mr. Ashok Kumar Rout" || 
            s.name === "Mrs. Sunita Patnaik" || 
            s.name === "Mr. Ranjan Kumar Nayak"
          );
          if (hasOldStaff || parsed.staff.length !== 13) {
            parsed.staff = defaultCollegeData.staff;
            updated = true;
          }
        }
        if (parsed.contact) {
          if (!parsed.contact.address || parsed.contact.address.includes("P.I. Mahavidyalaya Campus") || parsed.contact.address.includes("752001")) {
            parsed.contact.address = defaultCollegeData.contact.address;
            updated = true;
          }
          if (!parsed.contact.email || parsed.contact.email === "info@pimahavidyalay.com") {
            parsed.contact.email = defaultCollegeData.contact.email;
            updated = true;
          }
          if (!parsed.contact.website || parsed.contact.website === "https://pimahavidyalay.com") {
            parsed.contact.website = defaultCollegeData.contact.website;
            updated = true;
          }
        }
        if (!parsed.courses || parsed.courses.length === 0 || parsed.courses.some((c: any) => c.subjects.includes("Sanskrit") || c.subjects.includes("Biology") || c.name.includes("Programs"))) {
          parsed.courses = defaultCollegeData.courses;
          updated = true;
        }
        if (parsed.logoImage === undefined || parsed.logoImage === "" || parsed.logoImage === defaultCollegeData.about.principalImage) {
          parsed.logoImage = defaultCollegeData.logoImage;
          updated = true;
        }
        if (updated) {
          localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(parsed));
        }
        setCollegeData(parsed);
      }
    } catch (e) {
      console.error('Error loading stored configuration:', e);
    }

    try {
      const storedMessages = localStorage.getItem(MESSAGES_STORAGE_KEY);
      if (storedMessages) {
        setMessages(JSON.parse(storedMessages));
      }
    } catch (e) {
      console.error('Error loading stored student messages:', e);
    }

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Save changes wrapper
  const updateCollegeData = (updated: CollegeData) => {
    setCollegeData(updated);
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(updated));
    triggerSaveBanner();
  };

  const triggerSaveBanner = () => {
    setSaveBanner(true);
    setTimeout(() => {
      setSaveBanner(false);
    }, 3500);
  };

  // Sub-section state handlers
  const handleUpdateHero = (updatedHero: CollegeData['hero']) => {
    updateCollegeData({ ...collegeData, hero: updatedHero });
  };

  const handleUpdateNotices = (updatedNotices: CollegeData['notices']) => {
    updateCollegeData({ ...collegeData, notices: updatedNotices });
  };

  const handleUpdateAbout = (updatedAbout: CollegeData['about']) => {
    updateCollegeData({ ...collegeData, about: updatedAbout });
  };

  const handleUpdateCourses = (updatedCourses: CollegeData['courses']) => {
    updateCollegeData({ ...collegeData, courses: updatedCourses });
  };

  const handleUpdateStaff = (updatedStaff: CollegeData['staff']) => {
    updateCollegeData({ ...collegeData, staff: updatedStaff });
  };

  const handleUpdateActivities = (updatedActivities: CollegeData['activities']) => {
    updateCollegeData({ ...collegeData, activities: updatedActivities });
  };

  const handleUpdateAdmissions = (updatedAdmissions: CollegeData['admissions']) => {
    updateCollegeData({ ...collegeData, admissions: updatedAdmissions });
  };

  const handleUpdateContact = (updatedContact: CollegeData['contact']) => {
    updateCollegeData({ ...collegeData, contact: updatedContact });
  };

  // Student Messaging handlers
  const handleSendMessage = (msg: { name: string; email: string; message: string }) => {
    const newSms: StudentMessage = {
      id: `msg-${Date.now()}`,
      name: msg.name,
      email: msg.email,
      message: msg.message,
      timestamp: new Date().toLocaleString()
    };
    const updatedMessages = [newSms, ...messages];
    setMessages(updatedMessages);
    localStorage.setItem(MESSAGES_STORAGE_KEY, JSON.stringify(updatedMessages));
  };

  const handleClearMessage = (id: string) => {
    const updatedMessages = messages.filter(sms => sms.id !== id);
    setMessages(updatedMessages);
    localStorage.setItem(MESSAGES_STORAGE_KEY, JSON.stringify(updatedMessages));
  };

  const handleClearAllMessages = () => {
    setMessages([]);
    localStorage.removeItem(MESSAGES_STORAGE_KEY);
  };

  // Administrative Reset parameters
  const handleResetToDefaults = () => {
    setCollegeData(defaultCollegeData);
    localStorage.removeItem(CONFIG_STORAGE_KEY);
    triggerSaveBanner();
  };

  const handleLoadConfig = (importedConfig: CollegeData) => {
    setCollegeData(importedConfig);
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(importedConfig));
    triggerSaveBanner();
  };

  return (
    <div className="min-h-screen bg-white relative flex flex-col justify-between">
      
      {/* Header Sticky Menus */}
      <Header 
        isAdmin={isAdmin} 
        setIsAdmin={setIsAdmin} 
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        logoImage={collegeData.logoImage}
        onUpdateLogo={(newLogo) => updateCollegeData({ ...collegeData, logoImage: newLogo })}
      />

      {/* Main Body */}
      <main className="flex-1">
        
        {currentPage === 'home' ? (
          <>
            {/* Hero banner */}
            <Hero 
              data={collegeData.hero} 
              isAdmin={isAdmin} 
              onUpdate={handleUpdateHero} 
              onNavigate={(page) => {
                setCurrentPage(page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* Comprehensive Portal Bento Directory */}
            <PortalBento 
              onNavigate={(page) => {
                setCurrentPage(page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              notices={collegeData.notices}
              admissions={collegeData.admissions}
              contact={collegeData.contact}
            />
          </>
        ) : (
          <div id="portal-department-page" className="pt-20 min-h-screen bg-slate-50 flex flex-col justify-start">
            {/* Target Component Content Rendering */}
            <div className="flex-1">
              {currentPage === 'notices' && (
                <NoticeBoard 
                  notices={collegeData.notices} 
                  isAdmin={isAdmin} 
                  onUpdate={handleUpdateNotices} 
                />
              )}
              {currentPage === 'about' && (
                <div className="flex flex-col bg-white">
                  <AboutSection 
                    data={collegeData.about} 
                    isAdmin={isAdmin} 
                    onUpdate={handleUpdateAbout} 
                  />
                  <div className="border-t border-slate-100 bg-slate-50/50">
                    <StaffSection 
                      staff={collegeData.staff} 
                      isAdmin={isAdmin} 
                      onUpdate={handleUpdateStaff} 
                    />
                  </div>
                </div>
              )}
              {currentPage === 'academics' && (
                <AcademicsSection 
                  courses={collegeData.courses} 
                  isAdmin={isAdmin} 
                  onUpdate={handleUpdateCourses} 
                />
              )}
              {currentPage === 'activities' && (
                <ActivitiesSection 
                  activities={collegeData.activities} 
                  isAdmin={isAdmin} 
                  onUpdate={handleUpdateActivities} 
                />
              )}
              {currentPage === 'admissions' && (
                <AdmissionsSection 
                  data={collegeData.admissions} 
                  isAdmin={isAdmin} 
                  onUpdate={handleUpdateAdmissions} 
                />
              )}
              {currentPage === 'contact' && (
                <ContactSection 
                  data={collegeData.contact}
                  messages={messages}
                  onSendMessage={handleSendMessage}
                  onClearMessage={handleClearMessage}
                  isAdmin={isAdmin}
                  onUpdate={handleUpdateContact}
                />
              )}
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <Footer logoImage={collegeData.logoImage} />

      {/* Admin Central Parameter Control terminal widget */}
      <AdminPanel 
        data={collegeData}
        messages={messages}
        onUpdate={updateCollegeData}
        onClearAllMessages={handleClearAllMessages}
        onResetToDefaults={handleResetToDefaults}
        onLoadConfig={handleLoadConfig}
        isAdmin={isAdmin}
        setIsAdmin={setIsAdmin}
      />

      {/* Success Notification Banner on Edit/Save */}
      {saveBanner && (
        <div className="fixed bottom-6 left-6 z-50 bg-navy text-white text-xs px-4 py-3 rounded-xl border border-gold/40 shadow-2xl flex items-center gap-2.5 animate-fade-up select-none max-w-sm">
          <CheckCircle2 className="w-5 h-5 text-gold shrink-0 stroke-[2.5]" />
          <div>
            <span className="font-extrabold block text-gold-light">Changes Saved Instantly</span>
            <span className="text-white/70 text-[10px]">Your portal adjustments are active and cached in local memory.</span>
          </div>
        </div>
      )}

    </div>
  );
}
