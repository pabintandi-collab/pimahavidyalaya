import { PageType, NoticeState, AdmissionsState, ContactState } from '../types';
import { 
  Megaphone, BookOpen, GraduationCap, Award, Compass, Mail, 
  ArrowRight, BookOpenCheck, ShieldAlert, CheckCircle2, ChevronRight, Phone, MapPin 
} from 'lucide-react';

interface PortalBentoProps {
  onNavigate: (page: PageType) => void;
  notices: NoticeState[];
  admissions: AdmissionsState;
  contact: ContactState;
}

export default function PortalBento({ onNavigate, notices, admissions, contact }: PortalBentoProps) {
  
  // Pick latest 2 notices for live feed
  const liveNotices = notices.slice(0, 2);

  // Take first 3 SAMS steps for visual flow
  const samsSteps = admissions.steps.slice(0, 3);

  return (
    <section id="portal-directory" className="py-20 bg-slate-50 border-y border-slate-200 select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header with glowing visual indicator */}
        <div className="text-center max-w-3xl mx-auto mb-16 select-none">
          <span className="inline-flex items-center gap-1.5 bg-navy/10 text-navy text-[10px] uppercase font-black tracking-widest px-3.5 py-1.5 rounded-full mb-3">
            <span className="h-2 w-2 rounded-full bg-gold animate-ping"></span>
            Campus Information Network
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-extrabold text-navy tracking-tight leading-none">
            Digital Portal <span className="text-gold">Departments</span>
          </h2>
          <p className="text-slate-500 font-medium text-xs sm:text-sm mt-3 max-w-xl mx-auto leading-relaxed">
            Choose a department to read official documentation, search course databases, and engage directly with college units.
          </p>
        </div>

        {/* Dynamic Asymmetric Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Card 1: Live Notice Board - Spans 2 Columns on desktop */}
          <div 
            onClick={() => onNavigate('notices')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 lg:col-span-2 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            {/* Top orange status bar */}
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-red-500 to-amber-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold shadow-inner">
                  <Megaphone className="w-5 h-5 animate-pulse" />
                </div>
                <span className="text-[10px] font-extrabold uppercase px-3 py-1 bg-rose-50 text-rose-700 border border-rose-100 rounded-full">
                  {notices.length} Announcements Active
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Bulletins & Circulars
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  Notice Board
                </h3>
                <p className="text-slate-500 text-xs max-w-xl leading-relaxed">
                  Real-time exam routines, academic schedules, results announcements, and national holiday notices certified by the Principal of PIM.
                </p>
              </div>

              {/* LIVE BULLETIN FEED INTEGRATION */}
              <div className="mt-5 space-y-2.5 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest block mb-1">
                  Live Feed Preview
                </span>
                {liveNotices.map((notice) => (
                  <div key={notice.id} className="flex items-start gap-2.5 text-xs">
                    <span className="mt-1 bg-gold/15 text-gold-light border border-gold/30 text-[9px] font-black uppercase px-2 py-0.5 rounded shrink-0">
                      {notice.type}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-slate-700 font-bold line-clamp-1 group-hover:text-navy transition-colors">
                        {notice.title}
                      </p>
                      <span className="text-[9px] text-slate-400">{notice.date}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-slate-400 mt-1 shrink-0" />
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                View All Circulars
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Card 2: About Institution - Spans 1 Column */}
          <div 
            onClick={() => onNavigate('about')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold shadow-inner">
                  <BookOpen className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-100 rounded-full">
                  Since 1985
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Our Identity
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  About Institution
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Discover our history of higher secondary teaching, the Principal's physical speech, administrative guidelines, and our dedicated faculty roster.
                </p>
              </div>

              {/* Quick Info bullet labels */}
              <div className="mt-5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-700 font-bold bg-slate-50/50 p-2 rounded-xl">
                  <span className="text-gold">★</span>
                  <span>DHSE & SAMS Odisha Registered</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-700 font-bold bg-slate-50/50 p-2 rounded-xl">
                  <span className="text-blue-500">✦</span>
                  <span>UGC Act 2(f) & 12(B) Aided</span>
                </div>
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                View Institution Profile
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Card 3: Academics & Syllabus - Spans 1 Column */}
          <div 
            onClick={() => onNavigate('academics')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold shadow-inner">
                  <Award className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-full">
                  Streams Directory
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Course Curriculums
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  Academics
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Browse detailed stream configurations for Higher Secondary (+2) and Undergrad Honours Degree (+3) in Arts and Science faculties.
                </p>
              </div>

              {/* Stream badges visualization */}
              <div className="mt-5 flex flex-wrap gap-1.5">
                {['+2 Arts Stream', '+2 Science Stream', '+3 Degree Arts', '+3 Degree Science'].map((st) => (
                  <span key={st} className="text-[9px] font-extrabold bg-slate-100 text-slate-700 px-2 py-1 rounded-md border border-slate-200/60">
                    {st}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                Explore Syllabi
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Card 4: SAMS Admissions - Spans 2 Columns on desktop */}
          <div 
            onClick={() => onNavigate('admissions')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 lg:col-span-2 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-gold via-amber-500 to-yellow-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-yellow-50 text-amber-600 flex items-center justify-center font-bold shadow-inner">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-black uppercase px-3 py-1 bg-amber-500 text-navy font-bold border border-gold rounded-full">
                  Apply via SAMS Odisha
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Online CAF Registrations
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  Admissions Portal
                </h3>
                <p className="text-slate-500 text-xs max-w-xl leading-relaxed">
                  Step-by-step guidelines for SAMS CAF form applications, eligibility checks, cutoff analytics, required document verifications, fees, and timelines.
                </p>
              </div>

              {/* TIMELINE INTELLIGENCE INTEGRATION */}
              <div className="mt-5 space-y-2 bg-amber-500/5 p-4 rounded-2xl border border-gold/15">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest block mb-1">
                  Active SAMS Timeline Steps
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {samsSteps.map((step) => (
                    <div key={step.stepNum} className="bg-white/60 p-2.5 rounded-xl border border-slate-100 flex gap-2">
                      <span className="w-5 h-5 rounded-full bg-gold/15 text-gold-light border border-gold/30 text-[10px] font-black flex items-center justify-center shrink-0">
                        {step.stepNum}
                      </span>
                      <div className="min-w-0">
                        <h4 className="text-[10px] font-black text-navy truncate leading-tight">{step.title}</h4>
                        <p className="text-[9px] text-slate-400 leading-tight line-clamp-1">{step.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                Launch Admissions Desk
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Card 5: Student Life / Extension - Spans 1 Column */}
          <div 
            onClick={() => onNavigate('activities')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-purple-500 to-indigo-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shadow-inner">
                  <Compass className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-full">
                  8+ Gallery Units
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Extracurricular Activities
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  Student Life
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Participate in Extension units including the National Cadet Corps (NCC) drill platoon, National Service Scheme (NSS) social wellness drives, and physical athletics.
                </p>
              </div>

              {/* Dynamic checkmark bullet items */}
              <div className="mt-5 space-y-2">
                <div className="flex items-center gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="font-bold">NCC Cadet Platoon</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                  <span className="font-bold">NSS Camp & Seva Team</span>
                </div>
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                View Student Gallery
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* Card 6: Contact & Helpdesk - Spans 1 Column */}
          <div 
            onClick={() => onNavigate('contact')}
            className="group relative bg-white border border-slate-200 rounded-3xl p-6 transition-all duration-300 transform hover:-translate-y-1.5 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden"
          >
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-teal-500 to-cyan-500" />
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold shadow-inner">
                  <Mail className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-extrabold uppercase px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-100 rounded-full">
                  Reach Out
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">
                  Direct Messaging Inboxes
                </span>
                <h3 className="text-navy text-lg font-black tracking-tight group-hover:text-gold transition-colors">
                  Contact Helpdesk
                </h3>
                <p className="text-slate-500 text-xs leading-relaxed">
                  Submit real inquiries about admissions, cutoffs or courses, find exact Google Maps coordinates and email/phone directories.
                </p>
              </div>

              {/* CONTACT DETAILS INTEGRATION */}
              <div className="mt-5 space-y-1.5 text-xs text-slate-600 bg-slate-50/70 p-3.5 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-gold shrink-0" />
                  <span className="font-bold">{contact.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-navy shrink-0" />
                  <span className="truncate max-w-[200px]" title={contact.address}>Junagarh, Kalahandi</span>
                </div>
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 mt-6 flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-navy/40 group-hover:text-navy transition-colors">
                Launch Helpdesk Unit
              </span>
              <div className="w-7 h-7 rounded-lg bg-slate-100 group-hover:bg-navy group-hover:text-white flex items-center justify-center transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
