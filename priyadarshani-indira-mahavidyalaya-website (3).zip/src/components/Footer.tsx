import { GraduationCap } from 'lucide-react';
import Logo from './Logo';

interface FooterProps {
  logoImage?: string;
}

export default function Footer({ logoImage }: FooterProps) {
  return (
    <footer className="bg-navy pt-20 pb-10 border-t border-white/10 select-none text-white/50 text-xs text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 sm:gap-8 pb-14 border-b border-white/10">
          
          {/* Brand block */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Logo src={logoImage} size={40} className="bg-white rounded-lg p-0.5 border border-white/20 shadow flex items-center justify-center shrink-0" />
              <span className="font-serif font-extrabold text-white text-base">Priyadarshani Indira Mahavidyalaya</span>
            </div>
            <p className="text-white/60 leading-relaxed max-w-xs">
              Empowering Education for a Better Tomorrow — building scholarly leaders, scientific minds, and changemakers since 1985 in Odisha.
            </p>
            <div className="flex gap-2 pt-2">
              <a href="#" className="w-8 h-8 rounded bg-white/5 hover:bg-gold hover:text-navy text-white text-sm flex items-center justify-center transition-all" title="PIDC Facebook">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="w-8 h-8 rounded bg-white/5 hover:bg-gold hover:text-navy text-white text-sm flex items-center justify-center transition-all" title="PIDC Instagram">
                <i className="fab fa-instagram"></i>
              </a>
            </div>
            <p className="text-[10px] text-white/30 tracking-tight leading-none mt-2">Connect with <strong>PIDC</strong> online.</p>
          </div>

          {/* Quick links block */}
          <div>
            <h4 className="font-serif font-bold text-gold-light text-sm uppercase tracking-wider mb-4">
              Quick Directory
            </h4>
            <ul className="space-y-2.5 font-medium">
              <li><a href="#about" className="hover:text-gold transition-colors">About Us</a></li>
              <li><a href="#academics" className="hover:text-gold transition-colors">Academics</a></li>
              <li><a href="#activities" className="hover:text-gold transition-colors">Student Life</a></li>
              <li><a href="#staff" className="hover:text-gold transition-colors">Administration</a></li>
              <li><a href="#admissions" className="hover:text-gold transition-colors block font-semibold text-gold-light">Online SAMS application</a></li>
            </ul>
          </div>

          {/* Programs quick links */}
          <div>
            <h4 className="font-serif font-bold text-gold-light text-sm uppercase tracking-wider mb-4">
              Academic Streams
            </h4>
            <ul className="space-y-2.5 font-medium">
              <li><a href="#academics" className="hover:text-gold transition-colors">+2 Arts Curriculum</a></li>
              <li><a href="#academics" className="hover:text-gold transition-colors">+2 Science Curriculum</a></li>
              <li><a href="#academics" className="hover:text-gold transition-colors">+3 Degree Honors (Arts)</a></li>
              <li><a href="#academics" className="hover:text-gold transition-colors">+3 Degree Honors (Science)</a></li>
            </ul>
          </div>

          {/* Affiliation standards */}
          <div>
            <h4 className="font-serif font-bold text-gold-light text-sm uppercase tracking-wider mb-4">
              College Affiliations
            </h4>
            <p className="text-white/60 leading-relaxed mb-4">
              Affiliated fully under Odisha SAMS Higher Education Board and registered under UGC standards representing traditional excellence.
            </p>
            <div className="flex gap-2 select-none">
              <span className="bg-white/5 border border-white/10 text-white/70 text-[9px] font-black px-2 py-1 rounded">UGC UGC 12(B)</span>
              <span className="bg-white/5 border border-white/10 text-white/70 text-[9px] font-black px-2 py-1 rounded">SAMS OK</span>
            </div>
          </div>

        </div>

        {/* Footer bottom */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 font-medium text-white/30 text-[11px]">
          <p>© 2026 <span className="text-gold">Priyadarshani Indira Mahavidyalaya</span>. All rights reserved.</p>
          <div className="flex gap-4">
            <span className="text-white/20">Affiliated aided college Odisha</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
