import React, { useState, useEffect } from 'react';
import { HeroState, PageType } from '../types';
import { GraduationCap, Compass, Sparkles, Award, Edit, Save, Undo2, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeroProps {
  data: HeroState;
  isAdmin: boolean;
  onUpdate: (updated: HeroState) => void;
  onNavigate?: (page: PageType) => void;
}

export default function Hero({ data, isAdmin, onUpdate, onNavigate }: HeroProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<HeroState>({ ...data });

  const slides = data.slideshow && data.slideshow.length > 0
    ? data.slideshow
    : [
        "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1601058268499-e52658b8bb88?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1600&q=80",
        "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=1600&q=80"
      ];

  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto-play interval
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [slides.length]);

  const handleStartEdit = () => {
    setFormData({ ...data });
    setIsEditing(true);
  };

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePrevSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const handleNextSlide = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden bg-navy pt-24 pb-12 select-none"
    >
      {/* Background Image Slideshow */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <AnimatePresence initial={false} mode="wait">
          <motion.img
            key={currentSlide}
            src={slides[currentSlide]}
            alt={`Cultural stage performance slide ${currentSlide}`}
            referrerPolicy="no-referrer"
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.0, ease: "easeInOut" }}
            className="absolute inset-0 w-full h-full object-cover object-center"
          />
        </AnimatePresence>
        
        {/* Multi-layered elegant gradient masks for pristine text legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-navy/95 via-navy/80 to-navy/40 z-0" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-navy/40 z-0" />
        <div className="absolute inset-0 bg-black/35 z-0" />
      </div>
      
      {/* Absolute decorative circle rails (Faded for background depth) */}
      <div className="absolute -right-36 top-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-gold/10 pointer-events-none flex items-center justify-center z-10 opacity-60">
        <div className="w-[500px] h-[500px] rounded-full border border-gold/5 flex items-center justify-center">
          <div className="w-[400px] h-[400px] rounded-full border border-gold/5" />
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 gap-12 items-center">
          
          {/* Main content column */}
          <div className="max-w-4xl flex flex-col items-start text-left">
            
            {/* Admin Badge Toggler */}
            {isAdmin && !isEditing && (
              <button
                onClick={handleStartEdit}
                className="mb-4 bg-amber-500 hover:bg-amber-400 text-navy text-xs font-extrabold px-3 py-1.5 rounded-lg flex items-center gap-1 shadow-lg transition-transform hover:scale-105 cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Configure Hero & Slideshow</span>
              </button>
            )}

            {isEditing ? (
              /* Inline Section Editor Panel */
              <div className="w-full bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/25 shadow-xl max-w-2xl mb-8">
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/10">
                  <div className="flex items-center gap-1.5 text-gold-light text-sm font-bold uppercase tracking-wider">
                    <Sparkles className="w-4 h-4" />
                    <span>Hero Copy & Slideshow Module</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsEditing(false)}
                      className="px-2.5 py-1 text-xs bg-white/10 text-white/80 hover:bg-white/20 rounded font-bold flex items-center gap-1"
                    >
                      <Undo2 className="w-3 h-3" /> Cancel
                    </button>
                    <button
                      onClick={handleSave}
                      className="px-2.5 py-1 text-xs bg-gold text-navy hover:bg-gold-light rounded font-extrabold flex items-center gap-1"
                    >
                      <Save className="w-3 h-3" /> Save Changes
                    </button>
                  </div>
                </div>

                <div className="space-y-4 text-xs font-sans text-white/90 max-h-[420px] overflow-y-auto pr-1">
                  <div>
                    <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Eyebrow Announcement</label>
                    <input
                      type="text"
                      name="eyebrow"
                      value={formData.eyebrow}
                      onChange={handleChange}
                      className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Title First Half</label>
                      <input
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                      />
                    </div>
                    <div>
                      <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Accent Second Half</label>
                      <input
                        type="text"
                        name="titleAccent"
                        value={formData.titleAccent}
                        onChange={handleChange}
                        className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gold/90 font-bold mb-1 uppercase tracking-wider">Slogan / Tagline Paragraph</label>
                    <textarea
                      name="tagline"
                      rows={3}
                      value={formData.tagline}
                      onChange={handleChange}
                      className="w-full bg-navy/60 border border-white/15 px-3 py-2 rounded text-white text-sm outline-none focus:border-gold-light resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Students stat</label>
                      <input type="text" name="statStudents" value={formData.statStudents} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Faculty stat</label>
                      <input type="text" name="statTeachers" value={formData.statTeachers} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Year stat</label>
                      <input type="text" name="statEstablish" value={formData.statEstablish} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                    <div>
                      <label className="block text-gold/80 font-bold text-[10px] mb-0.5">Success rate</label>
                      <input type="text" name="statSuccessRate" value={formData.statSuccessRate} onChange={handleChange} className="w-full bg-navy/50 border border-white/10 p-1.5 rounded text-white text-xs text-center" />
                    </div>
                  </div>

                  {/* Slideshow control inputs */}
                  <div>
                    <label className="block text-gold/90 font-bold mb-1.5 uppercase tracking-wider">Slideshow Image URLs (4 slides)</label>
                    <div className="space-y-2">
                      {[0, 1, 2, 3].map((idx) => {
                        const currentSlidesState = formData.slideshow || slides;
                        return (
                          <div key={idx} className="flex gap-2 items-center">
                            <span className="text-gold/90 font-mono text-[10px] font-bold bg-navy/80 py-1.5 px-2.5 rounded border border-white/10 select-none">
                              Slide {idx + 1}
                            </span>
                            <input
                              type="text"
                              value={currentSlidesState[idx] || ''}
                              onChange={(e) => {
                                const updatedSlides = [...currentSlidesState];
                                updatedSlides[idx] = e.target.value;
                                setFormData((prev) => ({ ...prev, slideshow: updatedSlides }));
                              }}
                              placeholder={`Paste slide ${idx + 1} image URL`}
                              className="w-full bg-navy/60 border border-white/15 px-3 py-1.5 rounded text-white text-xs outline-none focus:border-gold-light"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              /* Public Presentation view */
              <>
                <div className="inline-flex items-center gap-2 text-gold-light font-semibold text-xs tracking-widest uppercase mb-4">
                  <span className="w-7 h-0.5 bg-gold rounded-full" />
                  <span>{data.eyebrow}</span>
                </div>

                <h1 className="font-serif font-black text-white text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.08] tracking-tight mb-6">
                  {data.title}
                  <span className="block mt-1 bg-gradient-to-r from-gold-light via-yellow-200 to-amber-300 bg-clip-text text-transparent font-medium italic">
                    {data.titleAccent}
                  </span>
                </h1>

                <p className="text-white/70 text-base md:text-lg font-light leading-relaxed max-w-xl mb-8">
                  {data.tagline}
                </p>

                <div className="flex items-center gap-4 flex-wrap">
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      if (onNavigate) onNavigate('admissions');
                    }}
                    className="bg-gold hover:bg-gold-light text-navy text-sm sm:text-base font-bold px-6 py-3.5 rounded-xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-gold flex items-center gap-2 shrink-0 shadow-lg cursor-pointer z-10"
                  >
                    <GraduationCap className="w-5 h-5 stroke-[2.5]" />
                    <span>Apply Now</span>
                  </button>
                </div>
              </>
            )}

            {/* Quick stats grid */}
            <div className="flex gap-8 sm:gap-14 mt-12 pt-8 border-t border-white/10 flex-wrap w-full">
              <div>
                <div className="font-serif text-3xl font-extrabold text-white flex items-baseline gap-1">
                  {data.statStudents}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Students enrolled</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-white flex items-baseline gap-1">
                  {data.statTeachers}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Expert Teachers</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-white">
                  {data.statEstablish}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">Established</div>
              </div>
              <div>
                <div className="font-serif text-3xl font-extrabold text-gold-light">
                  {data.statSuccessRate}
                </div>
                <div className="text-xs text-white/50 tracking-wider uppercase mt-1">SAMS Score Rate</div>
              </div>
            </div>

          </div>

        </div>
      </div>

      {/* Slide Navigation Manual Controls & Dots */}
      <div className="absolute bottom-10 right-4 sm:right-10 z-20 flex items-center gap-3">
        <button
          onClick={handlePrevSlide}
          className="w-8 h-8 rounded-full border border-white/20 bg-navy/40 hover:bg-navy/80 hover:border-white/50 text-white flex items-center justify-center transition-colors cursor-pointer select-none"
          aria-label="Previous slide"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <div className="flex gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={(e) => {
                e.stopPropagation();
                setCurrentSlide(index);
              }}
              className={`h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                currentSlide === index
                  ? 'bg-gold w-6'
                  : 'bg-white/20 hover:bg-white/40 w-2.5'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        <button
          onClick={handleNextSlide}
          className="w-8 h-8 rounded-full border border-white/20 bg-navy/40 hover:bg-navy/80 hover:border-white/50 text-white flex items-center justify-center transition-colors cursor-pointer select-none"
          aria-label="Next slide"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </section>
  );
}
