import React, { useState } from 'react';
import { ActivityState } from '../types';
import { 
  X, Compass, Shield, HeartHandshake, Award, Bus, HelpCircle, 
  Sparkles, Save, Edit, BookOpenCheck, Image, Calendar, ChevronLeft, ChevronRight 
} from 'lucide-react';

const GALLERY_ITEMS = [
  {
    id: 'g1',
    title: 'NCC Cadet Parade Drill',
    category: 'NCC & NSS',
    image: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?q=80&w=800&auto=format&fit=crop',
    description: 'Our highly disciplined National Cadet Corps (NCC) division demonstrating supreme precision during state assembly parade drills.',
    date: 'Jan 2026'
  },
  {
    id: 'g2',
    title: 'NSS Village Upliftment Drive',
    category: 'NCC & NSS',
    image: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?q=80&w=800&auto=format&fit=crop',
    description: 'National Service Scheme volunteers conducting health education, primary sanitization sweeps, and wellness workshops in adjacent villages.',
    date: 'Mar 2026'
  },
  {
    id: 'g3',
    title: 'Inter-College Gold Athletics',
    category: 'Sports',
    image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=800&auto=format&fit=crop',
    description: 'Sensational track and field record breakthroughs by undergraduate champions during Kalahandi district-wide tournaments.',
    date: 'Feb 2026'
  },
  {
    id: 'g4',
    title: 'Saraswati Puja Floral Decoration',
    category: 'Cultural',
    image: 'https://images.unsplash.com/photo-1567591974574-e852636b14a9?q=80&w=800&auto=format&fit=crop',
    description: 'Sleek traditional decor, floral rangoli, and devotional stages handcrafted by the Students Cultural Committee.',
    date: 'Sep 2025'
  },
  {
    id: 'g5',
    title: 'Honours Research & Science Fair',
    category: 'Academic',
    image: 'https://images.unsplash.com/photo-1507413245164-6160d8298b31?q=80&w=800&auto=format&fit=crop',
    description: 'Chemistry and Physics senior students demonstrating innovative electromagnetic grids and solar system modules to visiting academies.',
    date: 'Nov 2025'
  },
  {
    id: 'g6',
    title: 'Modern Library Seminar Session',
    category: 'Academic',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800&auto=format&fit=crop',
    description: 'Guest lecture debate on youth civic duties, regional state policies, and high-impact micro-economic studies.',
    date: 'Dec 2025'
  },
  {
    id: 'g7',
    title: 'State Theater Ensemble Victory',
    category: 'Cultural',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=800&auto=format&fit=crop',
    description: 'Our university theatrical troop celebrating the championship trophy for their modern musical-drama adaptation.',
    date: 'Jan 2026'
  },
  {
    id: 'g8',
    title: 'Championship Volleyball Final',
    category: 'Sports',
    image: 'https://images.unsplash.com/photo-1592656094267-764a45110c37?q=80&w=800&auto=format&fit=crop',
    description: 'A stellar block shot seals the trophy for Kalahandi college volleyball delegates in a thrilling nail-biter.',
    date: 'Dec 2025'
  }
];

interface ActivitiesSectionProps {
  activities: ActivityState[];
  isAdmin: boolean;
  onUpdate: (updated: ActivityState[]) => void;
}

export default function ActivitiesSection({ activities, isAdmin, onUpdate }: ActivitiesSectionProps) {
  // Detail Modal popup state
  const [activeActivity, setActiveActivity] = useState<ActivityState | null>(null);

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<ActivityState | null>(null);

  // Photo Gallery state
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);

  const galleryCategories = ['All', 'NCC & NSS', 'Sports', 'Cultural', 'Academic'];

  const filteredGallery = selectedCategory === 'All'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter(item => item.category === selectedCategory);

  const getLucideIcon = (iconStr: string) => {
    switch (iconStr) {
      case 'hands-helping': return <HeartHandshake className="w-8 h-8 transition-transform" />;
      case 'shield-alt': return <Shield className="w-8 h-8 transition-transform" />;
      case 'medkit': return <Compass className="w-8 h-8 transition-transform" strokeWidth={2} />;
      case 'bus-alt': return <Bus className="w-8 h-8 transition-transform" />;
      case 'trophy': return <Award className="w-8 h-8 transition-transform" />;
      default: return <HelpCircle className="w-8 h-8 transition-transform" />;
    }
  };

  const handleStartEdit = (e: React.MouseEvent, act: ActivityState) => {
    e.stopPropagation(); // Avoid opening the detail dialog
    setFormData({ ...act });
    setEditingId(act.id);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;

    const updated = activities.map(item => item.id === formData.id ? formData : item);
    onUpdate(updated);
    setEditingId(null);
    setFormData(null);
  };

  return (
    <section id="activities" className="py-24 bg-navy text-white select-none relative overflow-hidden">
      
      {/* Visual background grids */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_left_bottom,rgba(201,150,10,0.06),transparent_40%)]" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="bg-white/10 text-gold-light border border-white/10 px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Campus Enrichment
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-white mt-4">
            Beyond the <span className="text-gold-light">Classroom Walls</span>
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-white/60 text-sm">
            Discover a rich portfolio of disciplined training, social extension modules, industrial expeditions, and community service leagues.
          </p>
        </div>

        {/* Card Grid list */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {activities.map((act) => (
            <div
              key={act.id}
              onClick={() => setActiveActivity(act)}
              className="bg-white/5 border border-white/10 hover:border-gold/40 hover:bg-gold hover:text-navy group rounded-2xl p-6 text-center shadow transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between items-center cursor-pointer min-h-[220px]"
            >
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-white/5 group-hover:bg-navy/10 flex items-center justify-center text-gold-light group-hover:text-navy transition-all duration-300 mb-4">
                  {getLucideIcon(act.icon)}
                </div>

                <h3 className="font-serif text-sm sm:text-base font-bold mb-2 group-hover:text-navy transition-colors">
                  {act.title}
                </h3>
                <p className="text-white/60 group-hover:text-navy/80 text-[11px] sm:text-xs leading-relaxed line-clamp-3">
                  {act.description}
                </p>
              </div>

              {/* Admin triggers */}
              {isAdmin && (
                <div className="mt-4 pt-4 border-t border-white/10 group-hover:border-navy/10 w-full flex justify-center">
                  <button
                    onClick={(e) => handleStartEdit(e, act)}
                    className="flex items-center gap-1.5 bg-navy text-white group-hover:bg-navy group-hover:text-gold text-[10px] font-black uppercase tracking-wider py-1 px-3 rounded-md shadow"
                  >
                    <Edit className="w-3 h-3 text-gold" />
                    <span>Edit</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Campus Student Life Photo Gallery Sub-section */}
        <div className="mt-24 border-t border-white/10 pt-16">
          
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="bg-gold/10 text-gold-light border border-gold/25 px-3.5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-gold rounded-full animate-pulse"></span>
              Capturing Moments
            </span>
            <h2 className="font-serif font-black text-2xl sm:text-3xl text-white mt-3">
              Campus <span className="text-gold-light">Life Gallery</span>
            </h2>
            <div className="w-[44px] h-[3px] bg-gold mx-auto mt-3 rounded" />
            <p className="text-slate-400 text-xs mt-3 leading-relaxed">
              Glimpses of cadet parade runs, rural camp programs, athletic triumphs, and senior exhibitions in real campus time.
            </p>
          </div>

          {/* Filter Category Tabs pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5 mb-10 select-none">
            {galleryCategories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all duration-300 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-gold text-navy shadow-md ring-2 ring-gold/25'
                    : 'bg-white/5 text-slate-300 border border-white/5 hover:bg-white/10 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Gallery Photo Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredGallery.map((item) => {
              // Get absolute index in entire set for proper lightbox navigation
              const absoluteIndex = GALLERY_ITEMS.findIndex(g => g.id === item.id);
              
              return (
                <div
                  key={item.id}
                  onClick={() => setActivePhotoIndex(absoluteIndex)}
                  className="group relative bg-white/5 border border-white/5 rounded-2xl overflow-hidden shadow-md cursor-pointer transition-all duration-500 hover:-translate-y-1 hover:shadow-xl hover:border-gold/35"
                >
                  <div className="relative aspect-video sm:aspect-square overflow-hidden bg-slate-900">
                    <img
                      src={item.image}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    {/* Shadow overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/35 to-transparent opacity-65 group-hover:opacity-75 transition-opacity" />
                    
                    {/* Floating Zoom icon on top-right */}
                    <div className="absolute top-3 right-3 p-2 bg-navy/80 text-gold rounded-xl opacity-0 group-hover:opacity-100 transition-all transform scale-90 group-hover:scale-100 pointer-events-none">
                      <Image className="w-3.5 h-3.5" />
                    </div>

                    {/* Meta info bottom-left */}
                    <div className="absolute bottom-4 inset-x-4">
                      <span className="text-[9px] font-black uppercase text-gold-light tracking-wide bg-gold/15 border border-gold-light/20 px-2 py-0.5 rounded-md">
                        {item.category}
                      </span>
                      <h4 className="font-serif text-sm font-black text-white mt-1.5 leading-snug">
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-1.5 text-slate-300 text-[10px] mt-1 font-medium">
                        <Calendar className="w-3 h-3 text-gold" />
                        <span>{item.date}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Empty fallback screen if no items exist */}
          {filteredGallery.length === 0 && (
            <div className="text-center py-16 bg-white/5 border border-dashed border-white/10 rounded-2xl">
              <p className="text-slate-400 text-sm font-medium">Currently no photos aligned in this selection.</p>
            </div>
          )}

        </div>

      </div>

      {/* Activity Details Modal Popup */}
      {activeActivity && editingId !== activeActivity.id && (
        <div className="fixed inset-0 z-50 bg-navy-mid/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl text-navy relative border border-slate-200 animate-fade-up">
            <button
              onClick={() => setActiveActivity(null)}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-gold-pale text-gold flex items-center justify-center text-2xl mb-4">
              ✨
            </div>

            <h3 className="font-serif font-bold text-xl text-navy mb-2">
              {activeActivity.title}
            </h3>
            <p className="text-slate-600 text-sm leading-relaxed mb-6">
              {activeActivity.description}
            </p>

            <div className="bg-slate-50 p-4 border border-slate-150 rounded-2xl text-slate-500 text-xs flex gap-2">
              <BookOpenCheck className="w-5 h-5 text-navy shrink-0" />
              <span>
                To volunteer or enlist, reach out directly during our student orientation schedules or contact our staff coordinator.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Roster Editor mini popup modal dialog */}
      {editingId && formData && (
        <div className="fixed inset-0 z-50 bg-navy/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSave}
            className="bg-white text-navy rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 border border-slate-150 animate-fade-up"
          >
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="font-serif font-bold text-navy text-sm uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-gold" />
                <span>Configure Student Activity Block</span>
              </span>
              <button
                type="button"
                onClick={() => setEditingId(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Activity title *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-sm text-navy outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Narrative Description</label>
              <textarea
                rows={4}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                required
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-xs text-slate-800 outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-navy hover:bg-navy-light text-white font-bold py-2.5 rounded-lg text-xs uppercase tracking-wider"
            >
              Apply Updates
            </button>
          </form>
        </div>
      )}

      {/* Dynamic Lightbox Photo details modal */}
      {activePhotoIndex !== null && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl bg-navy border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row min-h-[460px] animate-fade-up">
            
            {/* Top Close trigger */}
            <button
              onClick={() => setActivePhotoIndex(null)}
              className="absolute top-4 right-4 z-20 p-2.5 rounded-full bg-navy/80 hover:bg-gold hover:text-navy text-white transition-all shadow-md cursor-pointer"
              aria-label="Close Lightbox"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Left Box: The Large Image viewport with sliding controls */}
            <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden aspect-video md:aspect-auto">
              <img
                src={GALLERY_ITEMS[activePhotoIndex].image}
                alt={GALLERY_ITEMS[activePhotoIndex].title}
                referrerPolicy="no-referrer"
                className="max-h-[70vh] md:max-h-[85vh] max-w-full object-contain"
              />

              {/* Navigation overlay triggers */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setActivePhotoIndex((prev) => 
                    prev !== null ? (prev === 0 ? GALLERY_ITEMS.length - 1 : prev - 1) : null
                  );
                }}
                className="absolute left-4 p-3 rounded-full bg-navy/80 hover:bg-gold hover:text-navy text-white transition-all shadow cursor-pointer border border-white/10"
                aria-label="Previous Photo"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setActivePhotoIndex((prev) => 
                    prev !== null ? (prev === GALLERY_ITEMS.length - 1 ? 0 : prev + 1) : null
                  );
                }}
                className="absolute right-4 p-3 rounded-full bg-navy/80 hover:bg-gold hover:text-navy text-white transition-all shadow cursor-pointer border border-white/10"
                aria-label="Next Photo"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              {/* Position dots */}
              <div className="absolute bottom-4 flex items-center gap-1.5 z-10 bg-black/40 px-3 py-1.5 rounded-full backdrop-blur-sm">
                {GALLERY_ITEMS.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActivePhotoIndex(i)}
                    className={`w-1.5 h-1.5 rounded-full transition-all ${
                      activePhotoIndex === i ? 'bg-gold w-3' : 'bg-white/40'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Right Box: Descriptive sidebar */}
            <div className="w-full md:w-[320px] bg-navy border-t md:border-t-0 md:border-l border-white/10 p-6 sm:p-8 flex flex-col justify-between select-none">
              <div className="space-y-4">
                <span className="bg-gold/15 text-gold-light border border-gold-light/20 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest inline-block">
                  {GALLERY_ITEMS[activePhotoIndex].category}
                </span>
                
                <h3 className="font-serif text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
                  {GALLERY_ITEMS[activePhotoIndex].title}
                </h3>
                
                <div className="w-12 h-0.5 bg-gold-light rounded" />

                <p className="text-xs text-slate-300 leading-relaxed pt-2 opacity-95">
                  {GALLERY_ITEMS[activePhotoIndex].description}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-white/5 flex items-center justify-between text-slate-400 text-xs">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-gold/80" />
                  <span>Recorded: {GALLERY_ITEMS[activePhotoIndex].date}</span>
                </div>
                <span className="text-[10px] font-extrabold uppercase text-gold">
                  {activePhotoIndex + 1} / {GALLERY_ITEMS.length}
                </span>
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
