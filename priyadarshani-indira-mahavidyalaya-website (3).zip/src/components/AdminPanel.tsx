import React, { useState, useRef } from 'react';
import { CollegeData, StudentMessage } from '../types';
import { 
  Settings2, Download, Upload, RotateCcw, Save, CheckCircle2, 
  AlertCircle, Code, Copy, LayoutDashboard, Inbox, Trash2, MailOpen, X, User, Clock 
} from 'lucide-react';

interface AdminPanelProps {
  data: CollegeData;
  messages: StudentMessage[];
  onUpdate: (updated: CollegeData) => void;
  onClearAllMessages: () => void;
  onResetToDefaults: () => void;
  onLoadConfig: (config: CollegeData) => void;
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;
}

export default function AdminPanel({
  data,
  messages,
  onUpdate,
  onClearAllMessages,
  onResetToDefaults,
  onLoadConfig,
  isAdmin,
  setIsAdmin
}: AdminPanelProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'editor' | 'json' | 'inbox'>('editor');
  
  // JSON Direct Editor state
  const [jsonText, setJsonText] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [jsonSuccess, setJsonSuccess] = useState(false);

  // Copy success feedback state
  const [copiedState, setCopiedState] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Action: Open JSON editor and preload state
  const handleOpenJsonTab = () => {
    setJsonText(JSON.stringify(data, null, 2));
    setJsonError(null);
    setJsonSuccess(false);
    setActiveTab('json');
  };

  // Action: validate and save JSON editor
  const handleSaveJson = () => {
    try {
      const parsed = JSON.parse(jsonText) as CollegeData;
      // Basic validate schema
      if (!parsed.hero || !parsed.about || !parsed.contact || !parsed.notices) {
        throw new Error('Missing core college config elements (hero, about, contact, notices).');
      }
      onUpdate(parsed);
      setJsonError(null);
      setJsonSuccess(true);
      setTimeout(() => setJsonSuccess(false), 3000);
    } catch (err: any) {
      setJsonError(err?.message || 'Invalid JSON syntax. Inspect commas and quotes.');
    }
  };

  // Action: Export config JSON file
  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
    const dlAnchorElem = document.createElement('a');
    dlAnchorElem.setAttribute("href",     dataStr     );
    dlAnchorElem.setAttribute("download", "pimahavidyalaya_config.json");
    dlAnchorElem.click();
  };

  // Action: Import custom config JSON file
  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const files = e.target.files;
    if (!files || files.length === 0) return;

    fileReader.readAsText(files[0], "UTF-8");
    fileReader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string) as CollegeData;
        if (!parsed.hero || !parsed.notices || !parsed.about) {
          throw new Error('Config missing core identity keys.');
        }
        onLoadConfig(parsed);
        alert('Config file uploaded successfully! Main portal updated instantly.');
      } catch (err) {
        alert('Failed parsing config file. Make sure file contains valid Priyadarshani college schema JSON.');
      }
    };
  };

  // Action: Copy config to clipboard for manual code edits
  const handleCopyCode = () => {
    const code = `export const customCollegeConfig = ${JSON.stringify(data, null, 2)};`;
    navigator.clipboard.writeText(code).then(() => {
      setCopiedState(true);
      setTimeout(() => setCopiedState(false), 3500);
    });
  };

  return (
    <>
      {/* Floating control trigger gear */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-navy text-gold hover:text-gold-light p-4 rounded-full shadow-2xl z-40 transition-transform duration-300 hover:rotate-45 flex items-center justify-center border border-gold/30"
        title="Open college parameters Customizer terminal"
      >
        <Settings2 className="w-6 h-6 stroke-[2]" />
      </button>

      {/* Side drawer drawer dialog */}
      {isOpen && (
        <div className="fixed inset-y-0 right-0 max-w-lg w-full bg-slate-900 border-l border-white/10 shadow-2xl z-50 flex flex-col justify-between text-white animate-fade-up select-none">
          
          {/* Panel Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings2 className="w-5 h-5 text-gold-light stroke-[2.5]" />
              <div className="leading-none">
                <h3 className="font-serif font-black text-white text-base">Roster & Copy Editor</h3>
                <span className="text-[10px] text-white/40 font-bold uppercase tracking-widest mt-1 block">Administrative Terminal</span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white/50 hover:text-white p-1 rounded-full hover:bg-white/10 transition"
              title="Collapse"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab selectors */}
          <div className="flex bg-slate-950 border-b border-white/5 p-1 select-none">
            <button
              onClick={() => setActiveTab('editor')}
              className={`flex-1 py-2.5 text-xs font-bold uppercase tracking-wider rounded ${
                activeTab === 'editor' 
                  ? 'bg-white/10 text-gold-light font-extrabold shadow-inner' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 mx-auto mb-1 stroke-[2]" />
              <span>Workspace</span>
            </button>

            <button
              onClick={handleOpenJsonTab}
              className={`flex-1 py-2.5 text-xs font-bold uppercase tracking-wider rounded ${
                activeTab === 'json' 
                  ? 'bg-white/10 text-gold-light font-extrabold shadow-inner' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Code className="w-4 h-4 mx-auto mb-1 stroke-[2]" />
              <span>Direct JSON</span>
            </button>

            <button
              onClick={() => setActiveTab('inbox')}
              className={`flex-1 py-2.5 text-xs font-bold uppercase tracking-wider rounded relative ${
                activeTab === 'inbox' 
                  ? 'bg-white/10 text-gold-light font-extrabold shadow-inner' 
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              <Inbox className="w-4 h-4 mx-auto mb-1 stroke-[2]" />
              <span>Campus Inbox</span>
              {messages.length > 0 && (
                <span className="absolute top-2 right-4 bg-amber-500 text-navy font-black text-[9px] px-1.5 py-0.5 rounded-full leading-none">
                  {messages.length}
                </span>
              )}
            </button>
          </div>

          {/* Scrollable content console */}
          <div className="flex-1 overflow-y-auto p-6 scrollbar-thin dark-scroll space-y-6">
            
            {activeTab === 'editor' && (
              <div className="space-y-6 text-xs text-white/70 font-sans leading-relaxed">
                
                {/* Admin Mode Toggle Switch */}
                <div className={`p-4 rounded-2xl border transition-all duration-300 ${
                  isAdmin 
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-200' 
                    : 'bg-white/5 border-white/10 text-white/70'
                }`}>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <h5 className="text-white font-bold font-serif text-sm flex items-center gap-1.5">
                        <span className={`h-2.5 w-2.5 rounded-full ${isAdmin ? 'bg-amber-500 animate-pulse' : 'bg-white/30'}`} />
                        <span>Live Content Editor</span>
                      </h5>
                      <p className="text-[10px] text-white/50 mt-1 leading-normal">
                        {isAdmin 
                          ? 'Active! Hover over components (including the college logo/seal in the navbar) to edit text, change roles, or upload pictures directly on the page.' 
                          : 'Disabled. Turn this ON to instantly type and edit sections, upload photos, or replace the college logo seal.'}
                      </p>
                    </div>
                    <button
                      onClick={() => setIsAdmin(!isAdmin)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                        isAdmin ? 'bg-amber-500' : 'bg-slate-700'
                      }`}
                      aria-label="Toggle edit mode"
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                          isAdmin ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Logo & Seal Upload Box */}
                <div className="bg-slate-950 border border-white/5 p-4 rounded-2xl relative space-y-3.5">
                  <div className="text-[10px] uppercase tracking-widest text-gold-light font-black border-b border-white/10 pb-1.5 mb-2 select-none flex items-center justify-between">
                    <span>College Logo & Official Seal</span>
                    {data.logoImage ? (
                      <span className="text-[9px] bg-gold/15 text-gold px-1.5 py-0.5 rounded uppercase font-bold">Custom Seal Active</span>
                    ) : (
                      <span className="text-[9px] bg-white/5 text-white/40 px-1.5 py-0.5 rounded uppercase font-bold">Default Vector Seal</span>
                    )}
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white p-1.5 rounded-xl border border-white/10 flex items-center justify-center shrink-0 shadow-lg">
                      {data.logoImage ? (
                        <img 
                          src={data.logoImage} 
                          alt="Current Logo Seal" 
                          className="w-12 h-12 object-cover rounded-full"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-navy rounded-full flex items-center justify-center text-white text-[8px] font-bold leading-none select-none text-center p-1 font-serif">
                          Odisha Seal
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 space-y-2">
                      <p className="text-white/50 text-[11px] leading-relaxed">
                        Customize the secondary official seal shown in the navigation bar and footer. Square high-resolution images look best.
                      </p>
                      
                      <div className="flex gap-2">
                        <button
                          onClick={() => logoInputRef.current?.click()}
                          className="bg-amber-500 hover:bg-amber-400 text-navy font-bold py-1.5 px-3 rounded text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <Upload className="w-3 h-3 stroke-[2.5]" />
                          <span>Upload Image</span>
                        </button>
                        
                        {data.logoImage && (
                          <button
                            onClick={() => {
                              if (window.confirm('Remove your custom uploaded logo and revert back to the beautiful traditional vector seal?')) {
                                onUpdate({ ...data, logoImage: '' });
                              }
                            }}
                            className="bg-red-650/20 hover:bg-red-650/30 text-red-400 font-semibold py-1.5 px-2.5 rounded text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
                          >
                            Reset
                          </button>
                        )}
                      </div>

                      <input
                        type="file"
                        ref={logoInputRef}
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onloadend = () => {
                              onUpdate({ ...data, logoImage: reader.result as string });
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-white font-bold text-sm mb-2 font-serif flex items-center gap-1">
                    <span>⚡ Quick content modifications</span>
                  </h4>
                  <p className="text-white/60 leading-relaxed mb-4">
                    Modify the college details easily using immediate click-to-edit cards directly on the website landing pages, or use core export keys below to save your changes permanently.
                  </p>
                </div>

                {/* Import / Export Controls */}
                <div className="bg-slate-950 border border-white/5 p-4 rounded-2xl relative space-y-3.5">
                  <div className="text-[10px] uppercase tracking-widest text-gold-light font-black border-b border-white/10 pb-1.5 mb-2 select-none">
                    External Configuration Sync
                  </div>

                  <p className="text-white/50 text-[11px] leading-relaxed">
                    Export your changes as a JSON file and restore it in any session, or copy the TypeScript code block to paste into the college source code.
                  </p>

                  <div className="grid grid-cols-2 gap-3 pb-2">
                    <button
                      onClick={handleExportJson}
                      className="bg-white/10 hover:bg-white/15 text-white font-semibold py-2.5 px-3 rounded-lg flex items-center justify-center gap-1 border border-white/10 transition-colors"
                      title="Download configuration as pimahavidyalaya_config.json"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export JSON File</span>
                    </button>

                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="bg-white/10 hover:bg-white/15 text-white font-semibold py-2.5 px-3 rounded-lg flex items-center justify-center gap-1 border border-white/10 transition-colors"
                      title="Import custom pimahavidyalaya_config.json"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload JSON file</span>
                    </button>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleImportJson}
                      accept=".json"
                      className="hidden"
                    />
                  </div>

                  <button
                    onClick={handleCopyCode}
                    className="w-full bg-gold hover:bg-gold-light text-navy font-bold py-2.5 rounded-lg flex items-center justify-center gap-1.5 transition-colors shadow"
                  >
                    <Copy className="w-4 h-4" />
                    <span>{copiedState ? 'Copied Configuration!' : 'Copy Code Declaration'}</span>
                  </button>
                </div>

                {/* Reset button */}
                <div className="bg-red-500/10 border border-red-500/20 p-4.5 rounded-2xl">
                  <h5 className="text-white font-bold mb-1">Reset College parameters</h5>
                  <p className="text-white/50 text-[11px] mb-3 leading-relaxed">
                    Instantly clear custom configs and roll back the college content to the default pre-filled Odisha aided college directories.
                  </p>
                  <button
                    onClick={() => {
                      if (window.confirm('Reset all details back to default college standards? Your current custom edits will be lost.')) {
                        onResetToDefaults();
                      }
                    }}
                    className="bg-red-600 hover:bg-red-500 text-white font-bold py-2 px-4 rounded text-[10px] uppercase tracking-wider flex items-center gap-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset defaults</span>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'json' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center select-none text-xs">
                  <label className="text-white font-serif font-black flex items-center gap-1 text-[11px] uppercase tracking-wider">
                    <Code className="w-4 h-4 text-gold-light" />
                    <span>Raw Content Schema Code</span>
                  </label>
                  <button
                    onClick={handleSaveJson}
                    className="bg-gold hover:bg-gold-light text-navy font-black px-2.5 py-1 rounded text-[10px] uppercase tracking-wider flex items-center gap-1.5"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Verify Code</span>
                  </button>
                </div>

                {jsonError && (
                  <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3.5 rounded-xl text-xs flex gap-1.5">
                    <AlertCircle className="w-4.5 h-4.5 shrink-0" />
                    <span>{jsonError}</span>
                  </div>
                )}

                {jsonSuccess && (
                  <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-3.5 rounded-xl text-xs flex gap-1.5">
                    <CheckCircle2 className="w-4.5 h-4.5 shrink-0" />
                    <span>Valid structure! Website views updated instantly.</span>
                  </div>
                )}

                <textarea
                  value={jsonText}
                  onChange={(e) => setJsonText(e.target.value)}
                  rows={20}
                  className="w-full bg-slate-950 border border-white/10 rounded-xl p-4 text-[11px] font-mono text-emerald-300 outline-none focus:border-gold/30 resize-y"
                  placeholder="Insert valid college schema JSON text..."
                />
              </div>
            )}

            {activeTab === 'inbox' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center select-none pb-2 border-b border-white/10 mb-2">
                  <span className="font-serif font-black text-sm text-white uppercase tracking-wider">
                    Applicant message board
                  </span>
                  {messages.length > 0 && (
                    <button
                      onClick={() => {
                        if (window.confirm('Delete all messages recorded?')) onClearAllMessages();
                      }}
                      className="text-[10px] text-red-400 hover:text-red-300 uppercase tracking-wider font-extrabold flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Clear All</span>
                    </button>
                  )}
                </div>

                {messages.length > 0 ? (
                  <div className="space-y-3">
                    {messages.map(sms => (
                      <div key={sms.id} className="bg-slate-950 border border-white/5 p-4 rounded-2xl relative">
                        <div className="flex items-center gap-1.5 text-xs text-gold font-bold mb-1 pr-6">
                          <User className="w-3.5 h-3.5 text-white/50" />
                          <span>{sms.name}</span>
                          <span className="text-white/40 font-medium">({sms.email})</span>
                        </div>
                        <p className="text-white/80 text-[11px] sm:text-xs leading-relaxed max-w-sm">
                          "{sms.message}"
                        </p>
                        <div className="text-[9px] text-white/30 uppercase font-bold mt-2 flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>Received: {sms.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-950 border border-white/5 rounded-2xl p-10 text-center text-white/40">
                    <MailOpen className="w-8 h-8 text-white/20 mx-auto mb-2" />
                    <p className="font-semibold text-xs text-white/60">No pending student queries.</p>
                  </div>
                )}
              </div>
            )}

          </div>

          {/* Panel Footer */}
          <div className="p-6 border-t border-white/10 bg-slate-950 flex items-center justify-between text-[11px] text-white/40">
            <span>Priyadarshani Indira Mahavidyalaya builder</span>
            <span className="bg-white/5 border border-white/10 px-2 py-0.5 rounded text-[9px] font-bold text-white/60">V1.0.0</span>
          </div>

        </div>
      )}
    </>
  );
}
