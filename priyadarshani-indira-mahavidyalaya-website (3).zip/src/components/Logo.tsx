import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  src?: string;
}

export default function Logo({ className = '', size = 44, src }: LogoProps) {
  if (src) {
    return (
      <img
        id="college-official-seal"
        src={src}
        alt="Priyadarshani Indira Mahavidyalaya Official Logo Seal"
        width={size}
        height={size}
        className={`select-none shrink-0 object-cover rounded-full ${className}`}
        referrerPolicy="no-referrer"
        style={{ width: size, height: size }}
      />
    );
  }

  return (
    <svg
      id="college-official-seal"
      width={size}
      height={size}
      viewBox="0 0 400 400"
      className={`select-none shrink-0 ${className}`}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Definitions for text paths */}
      <defs>
        {/* Arc for top text: radius 152, centered at 200, 200 */}
        <path
          id="text-arc"
          d="M 52,200 A 148,148 0 1,1 348,200"
          fill="none"
        />
      </defs>

      {/* Background fill for clean contrast */}
      <circle cx="200" cy="200" r="190" fill="#ffffff" stroke="#101827" strokeWidth="3" />
      <circle cx="200" cy="200" r="184" fill="none" stroke="#101827" strokeWidth="1" />
      <circle cx="200" cy="200" r="152" fill="none" stroke="#101827" strokeWidth="2.5" />

      {/* Odia Text at the top arch: "ତମସୋ ମା ଜ୍ୟୋତିର୍ଗମୟ" (Tamaso Ma Jyotirgamaya) */}
      <text fill="#ef4444" className="font-serif" style={{ fontSize: '24px', fontWeight: 'bold', letterSpacing: '4.5px' }}>
        <textPath href="#text-arc" startOffset="50%" textAnchor="middle">
          ତମସୋ ମା ଜ୍ୟୋତିର୍ଗମୟ
        </textPath>
      </text>

      {/* Inner grid lines or divider arcs in the seal base */}
      <path d="M 64,240 A 136,136 0 0,0 336,240" fill="none" stroke="#101827" strokeWidth="2" />

      {/* LEFT: Odisha Style Temple (Deula) */}
      <g id="spire-group" stroke="#101827" strokeWidth="2.5" fill="#ffffff" strokeLinecap="round" strokeLinejoin="round">
        {/* Stylized Kalasa / Flag on top */}
        <path d="M 130,110 L 130,125" />
        <path d="M 130,115 L 115,120 L 130,123 Z" fill="#101827" strokeWidth="1.5" />
        {/* Amla (Circular top cap) */}
        <ellipse cx="130" cy="128" rx="10" ry="4" fill="#101827" />
        {/* Neck (Beha) */}
        <path d="M 124,132 L 136,132 L 134,138 L 126,138 Z" />
        {/* Gandi (Spire body) */}
        <path d="M 124,138 L 136,138 L 142,160 L 144,185 L 116,185 L 118,160 Z" />
        {/* Horizontal ribs of Gandi */}
        <line x1="122" y1="145" x2="138" y2="145" />
        <line x1="120" y1="152" x2="140" y2="152" />
        <line x1="118" y1="162" x2="142" y2="162" />
        <line x1="117" y1="172" x2="143" y2="172" />
        {/* Bada (Base of the temple) */}
        <rect x="112" y="185" width="36" height="30" rx="1" />
        <line x1="112" y1="195" x2="148" y2="195" />
        {/* Entrance shape */}
        <path d="M 124,215 L 124,200 L 136,200 L 136,215 Z" fill="#101827" />
        {/* Platform base */}
        <rect x="100" y="215" width="60" height="15" rx="2" />
        <rect x="90" y="230" width="80" height="12" rx="1" />
      </g>

      {/* CENTER: Monogram "PIN" with Cobra (Nag) / Trident shape as shown in the logo image */}
      <g id="monogram-group" stroke="#101827" strokeWidth="4.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
        {/* Stylized standing Cobra (Nag) with hood wrapping around the central axis */}
        {/* Central pillar / snake axis */}
        <line x1="196" y1="115" x2="196" y2="280" strokeWidth="5.5" />
        
        {/* Cobra Hood Outline & Details at the top */}
        <path d="M 196,160 C 182,148 174,130 178,110 C 182,90 196,84 196,84 C 196,84 210,90 214,110 C 218,130 210,148 196,160" strokeWidth="4" fill="#ffffff" />
        <ellipse cx="196" cy="112" rx="4" ry="7" fill="#101827" stroke="none" />
        
        {/* Snake body coils winding around the pillar */}
        <path d="M 196,270 C 172,255 172,235 196,220 C 220,205 220,185 196,170 C 178,160 186,150 196,145" strokeWidth="4" />
        
        {/* Letter "P" on the left side of the monogram */}
        <line x1="162" y1="145" x2="162" y2="265" strokeWidth="6" />
        <path d="M 162,145 C 205,145 205,195 162,195" strokeWidth="5.5" />
        
        {/* Nesting lowercase "i" inside/next to the loop */}
        <line x1="216" y1="195" x2="216" y2="265" strokeWidth="6" />
        <circle cx="216" cy="180" r="5" fill="#101827" stroke="none" />
        
        {/* Stylized letter "N" on the right side */}
        <line x1="236" y1="195" x2="236" y2="265" strokeWidth="6" />
        <path d="M 236,195 L 262,265" strokeWidth="5" />
        <line x1="262" y1="195" x2="262" y2="265" strokeWidth="6" />
      </g>

      {/* RIGHT: Banyan / Kalpavriksha Tree of Wisdom */}
      <g id="tree-group" stroke="#101827" strokeWidth="2.5" strokeLinejoin="round" fill="#ffffff">
        {/* Trunk */}
        <path d="M 275,235 L 273,195 L 270,185 L 276,185 L 277,195 Z" fill="#101827" />
        {/* Hanging roots */}
        <path d="M 264,195 L 264,225" strokeWidth="1.5" />
        <path d="M 284,195 L 284,225" strokeWidth="1.5" />
        
        {/* Leaves / Canopy circles in clean hollow white fills with thin dark outlines */}
        <circle cx="275" cy="180" r="22" />
        <circle cx="255" cy="165" r="18" />
        <circle cx="295" cy="170" r="18" />
        <circle cx="275" cy="150" r="22" />
        <circle cx="260" cy="145" r="14" />
        <circle cx="290" cy="145" r="14" />
        <circle cx="275" cy="130" r="10" />
        
        {/* Platform soil base */}
        <path d="M 235,235 L 315,235" strokeWidth="3.5" strokeLinecap="round" />
        <path d="M 245,242 L 305,242" strokeWidth="2" strokeLinecap="round" />
      </g>

      {/* BOTTOM: Five ceremonial circles/wheels of Odisha's Konark Sun Temple style */}
      <g id="konark-circles" stroke="#101827" strokeWidth="2.5" fill="#ffffff">
        <circle cx="120" cy="315" r="18" />
        <circle cx="160" cy="328" r="18" />
        <circle cx="200" cy="332" r="18" />
        <circle cx="240" cy="328" r="18" />
        <circle cx="280" cy="315" r="18" />
        
        {/* Center hub of wheels */}
        <circle cx="120" cy="315" r="4" fill="#101827" />
        <circle cx="160" cy="328" r="4" fill="#101827" />
        <circle cx="200" cy="332" r="4" fill="#101827" />
        <circle cx="240" cy="328" r="4" fill="#101827" />
        <circle cx="280" cy="315" r="4" fill="#101827" />
        
        {/* Spokes detail */}
        <path d="M 120,297 L 120,333 M 102,315 L 138,315" strokeWidth="1" />
        <path d="M 160,310 L 160,346 M 142,328 L 178,328" strokeWidth="1" />
        <path d="M 200,314 L 200,350 M 182,332 L 218,332" strokeWidth="1" />
        <path d="M 240,310 L 240,346 M 222,328 L 258,328" strokeWidth="1" />
        <path d="M 280,297 L 280,333 M 262,315 L 298,315" strokeWidth="1" />
      </g>

      {/* Decorative details inside seal */}
      <path d="M 58,260 L 78,280" stroke="#101827" strokeWidth="1.5" />
      <path d="M 342,260 L 322,280" stroke="#101827" strokeWidth="1.5" />
    </svg>
  );
}
