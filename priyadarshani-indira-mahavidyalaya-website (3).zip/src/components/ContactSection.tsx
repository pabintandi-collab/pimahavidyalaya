import React, { useState } from 'react';
import { ContactState, StudentMessage } from '../types';
import { 
  MapPin, Mail, Phone, ExternalLink, Send, Inbox, 
  Trash2, User, Clock, AlertCircle, Edit, Save, Undo2, Sparkles, AlertOctagon, CheckCircle2 
} from 'lucide-react';

interface ContactSectionProps {
  data: ContactState;
  messages: StudentMessage[];
  onSendMessage: (msg: { name: string; email: string; message: string }) => void;
  onClearMessage: (id: string) => void;
  isAdmin: boolean;
  onUpdate: (updated: ContactState) => void;
}

export default function ContactSection({ 
  data, 
  messages, 
  onSendMessage, 
  onClearMessage, 
  isAdmin, 
  onUpdate 
}: ContactSectionProps) {
  // Contact info editor state
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<ContactState>({ ...data });

  // Contact form submission state
  const [studentName, setStudentName] = useState('');
  const [studentEmail, setStudentEmail] = useState('');
  const [studentMessage, setStudentMessage] = useState('');
  const [formFeedback, setFormFeedback] = useState<string | null>(null);

  // Administrative messages view tab
  const [adminShowInbox, setAdminShowInbox] = useState(false);

  // Action: update contact metadata
  const handleSaveContact = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  // Action: send contact form
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim() || !studentEmail.trim() || !studentMessage.trim()) return;

    onSendMessage({
      name: studentName,
      email: studentEmail,
      message: studentMessage
    });

    setFormFeedback('Thank you! Your message has been recorded and submitted to Priyadarshani Indira Mahavidyalaya administration.');
    setStudentName('');
    setStudentEmail('');
    setStudentMessage('');

    setTimeout(() => {
      setFormFeedback(null);
    }, 6000);
  };

  return (
    <section id="contact" className="py-24 bg-slate-50 select-none border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-16 px-4">
          <span className="bg-navy-light/10 text-navy px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
            Helpdesk Directory
          </span>
          <h2 className="font-serif font-bold text-3xl sm:text-4xl text-navy mt-4">
            Connect With <span className="text-gold">Our Campus</span>
          </h2>
          <div className="w-[60px] h-1 bg-gold mx-auto mt-4 mb-4 rounded" />
          <p className="text-slate-500 text-sm">
            Have questions regarding CAF registrations, cutoffs, honours streams, or college events? Drop us a line.
          </p>
        </div>

        {/* Administration Inbox records prompt */}
        {isAdmin && (
          <div className="bg-amber-150 border border-amber-300 rounded-2xl p-4.5 mb-10 flex flex-col md:flex-row justify-between items-center gap-4 bg-amber-50/50">
            <div className="flex gap-2.5 items-center">
              <Inbox className="w-5 h-5 text-amber-600 shrink-0" />
              <div className="text-xs">
                <span className="font-extrabold text-navy font-serif">REGISTRAR INBOX BOARD ACTIVE:</span>
                <span className="text-slate-600 block sm:inline sm:ml-1.5">You have {messages.length} incoming messages recorded from SAMS applicants.</span>
              </div>
            </div>
            <div className="flex gap-2 w-full sm:w-auto shrink-0 select-none">
              <button
                onClick={() => setAdminShowInbox(!adminShowInbox)}
                className="w-full sm:w-auto bg-navy hover:bg-navy-light text-white font-bold text-[10px] uppercase tracking-wider py-2 px-4 rounded-lg shadow-sm"
              >
                {adminShowInbox ? 'Hide Student Inbox' : 'Review Student Messages'}
              </button>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="w-full sm:w-auto bg-amber-500 hover:bg-amber-400 text-navy font-bold text-[10px] uppercase tracking-wider py-2 px-4 rounded-lg shadow-sm"
              >
                {isEditing ? 'Cancel Details' : 'Configure Address Details'}
              </button>
            </div>
          </div>
        )}

        {/* Dynamic Inbox Dashboard View */}
        {isAdmin && adminShowInbox && (
          <div className="bg-white border-2 border-dashed border-navy rounded-3xl p-6.5 shadow-xl mb-12 animate-fade-up max-h-[420px] overflow-y-auto scrollbar-thin">
            <h4 className="font-serif font-extrabold text-navy text-sm uppercase tracking-wider pb-2 border-b border-slate-200 mb-4 flex items-center gap-1.5">
              <Inbox className="w-4 h-4 text-navy" />
              <span>Received General SAMS Queries ({messages.length})</span>
            </h4>

            {messages.length > 0 ? (
              <div className="space-y-4">
                {messages.map((sms) => (
                  <div key={sms.id} className="bg-slate-50 border border-slate-150 p-4 rounded-2xl relative">
                    <button
                      onClick={() => onClearMessage(sms.id)}
                      className="absolute top-4 right-4 p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded transition-colors"
                      title="Dismiss message archives"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    
                    <div className="flex items-center gap-1.5 text-xs text-navy font-extrabold mb-1">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{sms.name}</span>
                      <span className="text-slate-400 font-medium">({sms.email})</span>
                    </div>

                    <p className="text-slate-600 text-xs sm:text-sm leading-relaxed max-w-xl">
                      "{sms.message}"
                    </p>

                    <div className="text-[10px] text-slate-400 font-bold uppercase mt-2.5 flex items-center gap-1 leading-none select-none">
                      <Clock className="w-3 h-3 text-slate-300" />
                      <span>Received: {sms.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-slate-500 p-8 text-center text-xs sm:text-sm leading-relaxed bg-slate-50 border rounded-2xl">
                <AlertSquarePlaceholder />
                <p className="font-semibold text-slate-600">Your portal inbox is empty.</p>
                <p className="text-slate-400 text-xs mt-1">Student submissions sent via the right form will display here immediately.</p>
              </div>
            )}
          </div>
        )}

        {/* Contact info customization section */}
        {isEditing && (
          <div className="bg-white border-2 border-navy border-dashed rounded-3xl p-6.5 shadow-xl mb-12 animate-fade-up text-xs font-sans text-slate-700">
            <h4 className="font-serif font-extrabold text-navy text-sm uppercase tracking-wide pb-2 border-b mb-4 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-gold" style={{ strokeWidth: 2.5 }} />
              <span>Modify Institution Address Metrics</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Postal Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-slate-50 border p-2 rounded outline-none text-navy text-xs"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Office Admissions Email</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-slate-50 border p-2 rounded outline-none text-navy text-xs"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">Office Telephone lines</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 border p-2 rounded outline-none text-navy text-xs"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-extrabold text-[10px] uppercase tracking-wider mb-1">SAMS Link / Domain URL</label>
                <input
                  type="text"
                  value={formData.website}
                  onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                  className="w-full bg-slate-50 border p-2 rounded outline-none text-navy text-xs"
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end pt-4 select-none">
              <button onClick={() => setIsEditing(false)} className="px-3 py-1.5 bg-slate-300 font-bold rounded">Cancel</button>
              <button onClick={handleSaveContact} className="px-3 py-1.5 bg-navy text-white font-bold rounded">Save contact</button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column Desk Details Info */}
          <div className="col-span-1 lg:col-span-4 space-y-6 animate-fade-up">
            
            <div className="bg-slate-900 text-white rounded-3xl p-7 shadow-xl border border-white/5 relative overflow-hidden">
              <h3 className="font-serif font-extrabold text-gold-light text-base uppercase tracking-wider mb-6">
                Institutional Contact desk
              </h3>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gold-light shrink-0">
                    <MapPin className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider mb-1">Registered Address</div>
                    <div className="text-white/80 text-xs sm:text-sm leading-relaxed font-semibold">{data.address}</div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gold-light shrink-0">
                    <Mail className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider mb-1">Help Desk Email</div>
                    <div className="text-white/85 text-xs sm:text-sm font-semibold">{data.email}</div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gold-light shrink-0">
                    <Phone className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider mb-1">Office Telephone Desk</div>
                    <div className="text-white/85 text-xs sm:text-sm font-semibold">{data.phone}</div>
                  </div>
                </div>
              </div>

              <div className="border-t border-white/10 mt-6 pt-4 flex justify-between select-none items-center text-xs leading-none">
                <span className="text-white/50">Odisha SAMS desk portal</span>
                <a href={data.website} target="_blank" rel="noreferrer" className="text-gold-light hover:underline flex items-center gap-1">
                  <span>Visit web</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>



          </div>

          {/* Right Column Student Submission message form */}
          <div className="col-span-1 lg:col-span-8 animate-fade-up">
            
            <form onSubmit={handleFormSubmit} className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
              <h3 className="font-serif font-extrabold text-navy text-lg sm:text-xl tracking-tight mb-2">
                Send Us an Online Query
              </h3>
              <p className="text-slate-400 text-xs sm:text-sm mb-6">
                Fill the details below, and our administrative desk clerk will review your Common Application metrics.
              </p>

              {formFeedback && (
                <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                  <span>{formFeedback}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-slate-600 text-xs font-semibold mb-1.5">Candidate Full Name *</label>
                  <input
                    type="text"
                    required
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Enter full name"
                    className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-sm outline-none focus:bg-white focus:border-navy"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 text-xs font-semibold mb-1.5">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={studentEmail}
                    onChange={(e) => setStudentEmail(e.target.value)}
                    placeholder="candidate@work.com"
                    className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-sm outline-none focus:bg-white focus:border-navy"
                  />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-slate-600 text-xs font-semibold mb-1.5">Query Message / Comments *</label>
                <textarea
                  rows={4}
                  required
                  value={studentMessage}
                  onChange={(e) => setStudentMessage(e.target.value)}
                  placeholder="Ask questions relating to +2 or +3 Honours streams selection..."
                  className="w-full bg-slate-50 border border-slate-200 p-3 rounded-xl text-sm outline-none focus:bg-white focus:border-navy resize-none"
                />
              </div>

              <button
                type="submit"
                className="bg-navy hover:bg-navy-light text-white font-bold py-3.5 px-6 rounded-xl text-xs sm:text-sm tracking-wider uppercase shadow-md flex items-center justify-center gap-2 transition-colors select-none"
              >
                <Send className="w-4.5 h-4.5" />
                <span>Submit Query Desk</span>
              </button>
            </form>

          </div>

        </div>



      </div>
    </section>
  );
}

// Simple Helper graphic
function AlertSquarePlaceholder() {
  return (
    <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-2.5 text-slate-400 select-none text-xl">
      📭
    </div>
  );
}
