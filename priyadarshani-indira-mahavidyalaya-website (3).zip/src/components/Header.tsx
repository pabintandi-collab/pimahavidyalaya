import React, { useState, useEffect, useRef } from 'react';
import { Menu, X, Shield, Settings2, GraduationCap, Upload, RefreshCw } from 'lucide-react';
import Logo from './Logo';

import { PageType } from '../types';

interface HeaderProps {
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;
  currentPage: PageType;
  setCurrentPage: (page: PageType) => void;
  logoImage?: string;
  onUpdateLogo?: (logo: string) => void;
}

export default function Header({ isAdmin, setIsAdmin, currentPage, setCurrentPage, logoImage, onUpdateLogo }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showLogoHelp, setShowLogoHelp] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Notice Board', href: '#notices', isPageLink: true, page: 'notices' as PageType },
    { name: 'About Us', href: '#about', isPageLink: true, page: 'about' as PageType },
    { name: 'Academics', href: '#academics', isPageLink: true, page: 'academics' as PageType },
    { name: 'Student Life', href: '#activities', isPageLink: true, page: 'activities' as PageType },
    { name: 'Admissions', href: '#admissions', isPageLink: true, page: 'admissions' as PageType },
    { name: 'Contact', href: '#contact', isPageLink: true, page: 'contact' as PageType },
  ];

  const handleNavClick = (
    e: React.MouseEvent<HTMLAnchorElement>,
    link: { name: string; href: string; isPageLink?: boolean; page?: PageType }
  ) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    
    if (link.page) {
      setCurrentPage(link.page);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <nav
      id="navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || isAdmin || currentPage !== 'home'
          ? 'bg-navy/95 backdrop-blur-md shadow-lg py-3 border-b border-white/10'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4">
          {/* Logo with Admin Upload support */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0 order-2 lg:order-1 relative select-none">
            <a 
              href="#" 
              onClick={(e) => handleNavClick(e, { name: 'Home', href: '#', isPageLink: true, page: 'home' })}
              className="flex items-center gap-2.5 sm:gap-3 shrink-0 focus:outline-none"
            >
              <Logo 
                src={logoImage}
                size={60} 
                className="size-[60px] bg-white rounded-xl p-0.5 border border-white/20 shadow-md flex items-center justify-center shrink-0 cursor-pointer transition-transform hover:scale-[1.02]" 
              />
              <div className="leading-tight">
                 <div className="font-serif font-bold text-white text-xs min-[360px]:text-sm sm:text-lg tracking-tight line-clamp-1">
                   Priyadarshani Indira Mahavidyalaya
                 </div>
                <div className="text-[9px] sm:text-[10px] text-white/65 font-medium letter-spacing-[0.08em] uppercase">
                   Est. 1985 · Aided College
                </div>
              </div>
            </a>


          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-2 lg:order-2">
            {navLinks.map((link) => {
              const isActive = link.isPageLink 
                ? (currentPage === link.page)
                : (currentPage === 'home' && false); // Highlight page links specifically
              
              return (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link)}
                  className={`text-xs font-semibold px-3 py-2 rounded-lg transition-all ${
                    isActive 
                      ? 'bg-gold text-navy font-bold shadow-md' 
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {link.name}
                </a>
              );
            })}
          </div>

          {/* Right Action Widgets */}
          <div className="hidden sm:flex items-center gap-3 sm:order-3 lg:order-3">
            <a
              href="#admissions"
              onClick={(e) => handleNavClick(e, { name: 'Admissions', href: '#admissions', page: 'admissions' })}
              className="bg-gold hover:bg-gold-light text-navy text-sm font-bold px-4 py-2 rounded-lg transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
            >
              <GraduationCap className="w-4 h-4 stroke-[2.5]" />
              <span>Apply Now</span>
            </a>
          </div>

          {/* Mobile Navigation Controls */}
          <div className="flex lg:hidden items-center gap-2.5 order-1">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="h-11 w-11 flex items-center justify-center rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all border border-white/5 cursor-pointer"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5 text-gold-light" />}
            </button>
          </div>
        </div>
      </div>

      {/* Admin Mode Bar Under Nav */}
      {isAdmin && (
        <div className="bg-amber-500 text-navy font-bold text-[11px] py-1 text-center select-none shadow-sm flex items-center justify-center gap-2">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-600"></span>
          </span>
          <span>ADMINISTRATIVE CONTENT BUILDER ACTIVE — CLICK ANY HIGHLIGHT DRIVEN SECTION OR EDIT CARD CODES</span>
        </div>
      )}

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-[100%] inset-x-0 bg-navy/98 backdrop-blur-xl border-b border-white/10 py-6 px-4 flex flex-col gap-3 shadow-xl transition-all duration-300">
          {navLinks.map((link) => {
            const isActive = link.isPageLink && currentPage === link.page;
            return (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link)}
                className={`text-base font-medium p-3 rounded-lg transition-all text-center ${
                  isActive 
                    ? 'bg-gold text-navy font-bold shadow-md' 
                    : 'text-white/90 hover:text-gold-light hover:bg-white/5'
                }`}
              >
                {link.name}
              </a>
            );
          })}
          <div className="flex flex-col gap-2 pt-4 border-t border-white/10 text-center">
            <a
              href="#admissions"
              onClick={(e) => handleNavClick(e, { name: 'Admissions', href: '#admissions', page: 'admissions' })}
              className="bg-gold text-navy text-base font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 shadow-md w-full"
            >
              <GraduationCap className="w-5 h-5 stroke-[2.5]" />
              <span>Apply Online 2026</span>
            </a>
          </div>
        </div>
      )}
      {/* Interactive Custom Logo / Seal Upload Assistant Mode */}
      {showLogoHelp && (
        <div className="fixed inset-0 bg-navy/85 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-white/10 rounded-2xl max-w-sm w-full p-6 shadow-2xl relative animate-fade-up text-white font-sans text-xs">
            <button 
              onClick={() => setShowLogoHelp(false)}
              className="absolute top-4 right-4 text-white/50 hover:text-white hover:bg-white/15 p-1.5 rounded-full transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-white/10 pb-3">
                <Settings2 className="w-4.5 h-4.5 text-gold stroke-[2]" />
                <h3 className="font-serif font-bold text-base text-white">How to Add Custom Logo?</h3>
              </div>

              <div className="space-y-2 leading-relaxed text-white/80">
                <p>
                  To change the seal shown in the navbar and footer with your own college emblem or image:
                </p>
                <ol className="list-decimal pl-4 space-y-1.5 text-white/70">
                  <li>Click the <strong className="text-amber-400">Upload Image</strong> button below.</li>
                  <li>Choose any square photo, JPEG, PNG, or SVG from your device.</li>
                  <li>The emblem will replace the seal instantly on all pages!</li>
                </ol>
              </div>

              {/* Preview Box */}
              <div className="bg-slate-950 p-3 rounded-xl border border-white/5 flex flex-col items-center justify-center space-y-2">
                <span className="text-[9px] uppercase font-bold tracking-wider text-white/45">Current Live Logo Preview</span>
                <div className="bg-white p-2 rounded-xl flex items-center justify-center shadow-md">
                  <Logo src={logoImage} size={64} className="size-[64px]" />
                </div>
                <span className="text-[10px] font-bold text-gold-light">
                  {logoImage ? 'Custom Emblem Loaded' : 'Default Traditional Vector Seal'}
                </span>
              </div>

              {/* Direct Actions inside Modal */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-amber-500 hover:bg-amber-400 text-navy font-bold py-2.5 px-4 rounded-xl text-[11px] uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <Upload className="w-4 h-4 stroke-[2.5]" />
                  <span>Upload Image File</span>
                </button>

                {logoImage && onUpdateLogo && (
                  <button
                    onClick={() => {
                      if (window.confirm('Reset and restore the default vector seal?')) {
                        onUpdateLogo('');
                        setShowLogoHelp(false);
                      }
                    }}
                    className="w-full bg-red-650/15 hover:bg-red-650/25 border border-red-500/20 text-red-100 font-semibold py-2 px-4 rounded-xl text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset to Default Seal</span>
                  </button>
                )}
              </div>

              {/* Hidden file input anchor */}
              <input 
                type="file" 
                ref={fileInputRef}
                accept="image/*" 
                className="hidden" 
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      if (onUpdateLogo) {
                        onUpdateLogo(reader.result as string);
                        setShowLogoHelp(false);
                      }
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
