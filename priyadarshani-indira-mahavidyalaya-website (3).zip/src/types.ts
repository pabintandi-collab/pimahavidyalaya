export interface HeroState {
  eyebrow: string;
  title: string;
  titleAccent: string;
  tagline: string;
  statStudents: string;
  statTeachers: string;
  statEstablish: string;
  statSuccessRate: string;
  slideshow?: string[];
}

export type NoticeType = 'exam' | 'news' | 'results';

export interface NoticeState {
  id: string;
  type: NoticeType;
  title: string;
  date: string;
  url: string;
  isNew?: boolean;
}

export interface AboutState {
  eyebrow: string;
  title: string;
  titleAccent: string;
  content: string;
  principalTitle: string;
  principalText: string;
  principalAuthor: string;
  principalRole: string;
  principalImagePlaceholder: string;
  principalImage?: string;
  aboutImage?: string;
  aboutImageTitle?: string;
}

export type CourseStream = 'arts' | 'science' | 'degree';

export interface CourseState {
  id: string;
  name: string;
  description: string;
  stream: CourseStream;
  subjects: string[];
}

export type StaffType = 'faculty' | 'technical' | 'non-teaching';

export interface StaffState {
  id: string;
  name: string;
  role: string;
  department: string;
  type: StaffType;
}

export interface ActivityState {
  id: string;
  icon: string;
  title: string;
  description: string;
}

export interface AdmissionStep {
  stepNum: number;
  title: string;
  desc: string;
}

export interface ImportantDate {
  event: string;
  date: string;
}

export interface AdmissionsState {
  eyebrow: string;
  title: string;
  titleAccent: string;
  description: string;
  steps: AdmissionStep[];
  importantDates: ImportantDate[];
  eligibilityTitle: string;
  eligibilityItems: string[];
}

export interface ContactState {
  address: string;
  email: string;
  phone: string;
  website: string;
}

export interface StudentMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
}

export type PageType = 'home' | 'notices' | 'about' | 'academics' | 'activities' | 'staff' | 'admissions' | 'contact';

export interface CollegeData {
  hero: HeroState;
  notices: NoticeState[];
  about: AboutState;
  courses: CourseState[];
  staff: StaffState[];
  activities: ActivityState[];
  admissions: AdmissionsState;
  contact: ContactState;
  logoImage?: string;
}
