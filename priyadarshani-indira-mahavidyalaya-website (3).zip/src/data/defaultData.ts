import { CollegeData } from '../types';
import principalImageSrc from '../assets/images/regenerated_image_1780935966866.jpg';

export const defaultCollegeData: CollegeData = {
  hero: {
    eyebrow: "Welcome to Priyadarshani Indira Mahavidyalaya",
    title: "Empowering Minds,",
    titleAccent: "Shaping Futures",
    tagline: "Empowering Education for a Better Tomorrow — where academic excellence meets holistic development in a vibrant campus environment in Odisha.",
    statStudents: "1200+",
    statTeachers: "45+",
    statEstablish: "1985",
    statSuccessRate: "94%",
    slideshow: [
      "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1600&q=80",
      "https://images.unsplash.com/photo-1601058268499-e52658b8bb88?auto=format&fit=crop&w=1600&q=80",
      "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1600&q=80",
      "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&w=1600&q=80"
    ]
  },
  notices: [
    {
      id: "exam-1",
      type: "exam",
      title: "All type of Exam notices for +2 & +3 updated for Semester II.",
      date: "2026-05-24",
      url: "#"
    },
    {
      id: "exam-2",
      type: "exam",
      title: "Practical Examination schedule for Science Stream (2026).",
      date: "2026-05-20",
      url: "#"
    },
    {
      id: "exam-3",
      type: "exam",
      title: "Download hall tickets for upcoming mid-term examinations.",
      date: "2026-05-15",
      url: "#"
    },
    {
      id: "news-1",
      type: "news",
      title: "Annual Sports Day achievements and highlights published.",
      date: "2026-05-25",
      url: "#"
    },
    {
      id: "news-2",
      type: "news",
      title: "Recent college achievements and state-level event coverage in local dailies.",
      date: "2026-05-22",
      url: "#"
    },
    {
      id: "news-3",
      type: "news",
      title: "Science exhibition innovation award received by student delegation.",
      date: "2026-05-18",
      url: "#"
    },
    {
      id: "results-1",
      type: "results",
      title: "This Year +3 Degree Final Year Results (2025-26 Session) published.",
      date: "2026-05-26",
      url: "#"
    },
    {
      id: "results-2",
      type: "results",
      title: "Previous Year Result Archives & Stream-wise Topper Lists.",
      date: "2025-06-30",
      url: "#"
    },
    {
      id: "results-3",
      type: "results",
      title: "Re-evaluation applications open for Semester IV and Part-II candidates.",
      date: "2026-05-10",
      url: "#"
    }
  ],
  about: {
    eyebrow: "About the Institution",
    title: "A Legacy of",
    titleAccent: "Academic Excellence",
    content: "Founded in 1985, Priyadarshani Indira Mahavidyalaya is one of the premier fully aided colleges in Odisha, dedicated to delivering quality higher education and fostering empowerment in students.",
    principalTitle: "Principal's Desk",
    principalText: "Education is not merely the accumulation of facts, but the preparation for life itself. At P.I. Mahavidyalaya, our focus is on holistic development, academic rigor, and fostering a spirit of inquiry and leadership among all our students.",
    principalAuthor: "Sj. Pratap Ballav Panigrahi",
    principalRole: "Principal, Priyadarshini Indira Mahavidyalaya",
    principalImagePlaceholder: "Sj. Pratap Ballav Panigrahi is the Principal of Priyadarshini Indira Mahavidyalaya, dedicated to academic leadership.",
    principalImage: principalImageSrc,
    aboutImage: "",
    aboutImageTitle: "Main Entrance Gate"
  },
  courses: [
    {
      id: "course-1",
      name: "+2 Arts",
      description: "Foundational higher secondary main subjects equipping students with critical thinking, linguistic arts, and humanistic knowledge.",
      stream: "arts",
      subjects: ["Odia", "English", "Political Sc.", "History", "Information Technology", "Education", "Economics"]
    },
    {
      id: "course-2",
      name: "+2 Science",
      description: "Rigorous secondary scientific foundation prepares students with main subjects for higher professional technical and medical streams.",
      stream: "science",
      subjects: ["Odia", "English", "Physics", "Chemistry", "Math", "Botany", "Zoology", "Information Technology"]
    },
    {
      id: "course-3",
      name: "+3 Arts (HONS)",
      description: "Advanced undergraduate syllabus offering deep honors specializations in major humanities and social science systems under Kalahandi University.",
      stream: "degree",
      subjects: ["EDUCATION", "ECONOMICS", "POLITICAL SCIENCE", "ODIA", "HISTORY"]
    },
    {
      id: "course-4",
      name: "+3 Science (HONS)",
      description: "High-acclaim undergraduate honours modules in fundamental natural sciences and advanced laboratory practices.",
      stream: "degree",
      subjects: ["PHYSICS", "CHEMISTRY", "MATH", "BOTANY", "ZOOLOGY"]
    }
  ],
  staff: [
    {
      id: "staff-1",
      name: "Sj. Pratap Ballav Panigrahi",
      role: "Principal & Lecturer in Political Science",
      department: "Political Science",
      type: "faculty"
    },
    {
      id: "staff-8",
      name: "Mr. Kailash Meher",
      role: "Lecturer in Political Science",
      department: "Political Science",
      type: "faculty"
    },
    {
      id: "staff-9",
      name: "Mr. Aditya Kumar Khamari",
      role: "Lecturer in Economics",
      department: "Economics",
      type: "faculty"
    },
    {
      id: "staff-10",
      name: "Mrs. Jasmin Banita Sahoo",
      role: "Lecturer in Education",
      department: "Education",
      type: "faculty"
    },
    {
      id: "staff-11",
      name: "Mrs. Sagarika Das",
      role: "Lecturer in History",
      department: "History",
      type: "faculty"
    },
    {
      id: "staff-12",
      name: "Mr. Biswa Ranjan Behera",
      role: "Lecturer in Odia",
      department: "Odia",
      type: "faculty"
    },
    {
      id: "staff-13",
      name: "Ms. Kalpana Bhoi",
      role: "Lecturer in English",
      department: "English",
      type: "faculty"
    },
    {
      id: "staff-14",
      name: "Mr. Imran Ahemad Khan",
      role: "Lecturer in Physics",
      department: "Physics",
      type: "faculty"
    },
    {
      id: "staff-15",
      name: "Mr. Rajesh Kumar Patel",
      role: "Lecturer in Chemistry",
      department: "Chemistry",
      type: "faculty"
    },
    {
      id: "staff-16",
      name: "Mr. Akash Meher",
      role: "Lecturer in Mathematics",
      department: "Mathematics",
      type: "faculty"
    },
    {
      id: "staff-17",
      name: "Mrs. Susmita Panda",
      role: "Lecturer in Zoology",
      department: "Zoology",
      type: "faculty"
    },
    {
      id: "staff-18",
      name: "Mr. Hemanta Kumar Rana",
      role: "Lecturer in Botany",
      department: "Botany",
      type: "faculty"
    },
    {
      id: "staff-19",
      name: "Mr. Ananta Narayan Dhangadamajhi",
      role: "Lecturer in IT",
      department: "Information Technology (IT)",
      type: "faculty"
    }
  ],
  activities: [
    {
      id: "act-1",
      icon: "hands-helping",
      title: "NSS (National Service Scheme)",
      description: "Promoting social welfare, rural medical camps, winter extension projects, and civic responsibility among youth."
    },
    {
      id: "act-2",
      icon: "shield-alt",
      title: "NCC (National Cadet Corps)",
      description: "Instilling discipline, state-level parades, leadership camps, survival drills, and patriotic national defense skills."
    },
    {
      id: "act-3",
      icon: "medkit",
      title: "Youth Red Cross",
      description: "Focusing on emergency disaster response, first aid training, blood donation camps, and community hygiene initiatives."
    },
    {
      id: "act-4",
      icon: "bus-alt",
      title: "Educational Study Tours",
      description: "Annual field trips bridging campus theory and historic research, industrial spots, and ecological sanctuaries."
    },
    {
      id: "act-5",
      icon: "trophy",
      title: "State Achievements",
      description: "Outstanding students winning state laureates in inter-college sports tracks, debates, and annual science exhibitions."
    }
  ],
  admissions: {
    eyebrow: "Admissions 2026–27",
    title: "Start Your Beautiful",
    titleAccent: "Academic Journey",
    description: "Our admission process is fully coordinated, transparent, and designed according to Odisha SAMS guidelines and merit ranking.",
    steps: [
      {
        stepNum: 1,
        title: "SAMS Odisha Online Registration",
        desc: "Submit your Common Application Form (CAF) online via SAMS Odisha portal and select Priyadarshani Indira Mahavidyalaya as your preferred choice."
      },
      {
        stepNum: 2,
        title: "Merit List Publication & Selection",
        desc: "Check selection round status. Merit reports are also published on our local college notice board."
      },
      {
        stepNum: 3,
        title: "Verification & Seat Enrollment",
        desc: "Bring original matriculation/secondary certificates, CLC (College Leaving Certificate), and migration forms for face-to-face registration."
      }
    ],
    importantDates: [
      {
        event: "SAMS Application Window",
        date: "June 05 – June 28, 2026"
      },
      {
        event: "First Selection Admission Process",
        date: "July 05 – July 10, 2026"
      },
      {
        event: "Second Selection & Spot Admission",
        date: "July 18 – July 22, 2026"
      },
      {
        event: "Inauguration & Classes Commence",
        date: "August 01, 2026"
      }
    ],
    eligibilityTitle: "Admission Eligibility Standards",
    eligibilityItems: [
      "For +2 Programs: SAMS CAF selection with valid 10th Board Certificate.",
      "For +3 Degree Programs: SAMS CAF selection with 10+2 Arts/Science passing certificate.",
      "Odia is mandatory as MIL subject or secondary school exam standard unless special exemption is granted."
    ]
  },
  contact: {
    address: "Priyadarshini Indira Mahavidyalaya, Junagarh, Kalahandi, Odisha, Pin-766014.",
    email: "info@pimahavidyalaya.in",
    phone: "+91 8847879687",
    website: "https://pimahavidyalaya.in"
  },
  logoImage: ""
};
